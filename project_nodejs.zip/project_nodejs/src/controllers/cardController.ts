import mongoose from "mongoose";
import Card from "../models/Card.js";
import { Request, Response } from 'express';

export interface RequestWithUser extends Request {
    user?: { id: string; [key: string]: any }; // Adjust this type according to what you actually store in req.user
}

// Create a New Card
export const createCard = async (req: RequestWithUser, res: Response) => {
  try {
    // Assuming req.user is set by auth middleware and contains the user ID
    if (!req.user) throw new Error('user not found');
    console.log(req.user)
    const card = new Card({
      ...req.body,
      user: req.user.id,
    });

    await card.save();
    res.status(201).json(card);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Update Card
export const updateCard = async (req: RequestWithUser, res: Response) => {
  try {
    const cardId = req.params.id;
    const card = await Card.findById(cardId);
    if (!req.user) throw new Error('user not found');

    if (!card) {
      return res.status(404).json({ message: 'Card not found' });
    }

    // Check if the user is the card owner or an admin
    if (card.user.toString() !== req.user.id && !req.user.isAdmin) {
      return res.status(401).json({ message: 'User not authorized' });
    }

    const updatedCard = await Card.findByIdAndUpdate(cardId, req.body, { new: true });
    res.json(updatedCard);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Like a Card
export const likeCard = async (req: RequestWithUser, res: Response) => {
  try {
    if (!req.user) throw new Error('user not found');

    const card = await Card.findById(req.params.id);
    if (!card) {
      return res.status(404).json({ message: 'Card not found' });
    }

    // Assuming req.user is set by auth middleware and contains the user ID
    // This is a simple toggle like logic, it can be more complex depending on your needs
    const userIdAsString = req.user.id; // This is already a string, no need to convert

    const index = card.likes.findIndex(likeId => likeId.toString() === userIdAsString);
    if (index > -1) {
      card.likes.splice(index, 1);
    } else {
      card.likes.push(new mongoose.Types.ObjectId(req.user.id));
    }

    await card.save();
    res.json(card);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
  return
};


export const deleteCard = async (req: RequestWithUser, res: Response) => {
  try {
    const cardId = req.params.id;
    const card = await Card.findById(cardId);
    if (!req.user) throw new Error('user not found');

    if (!card) {
      return res.status(404).json({ message: 'Card not found' });
    }

    // Check if the user is the card owner or an admin
    if (card.user.toString() === req.user.id || req.user.isAdmin) {
      await Card.findByIdAndDelete(cardId); // Use findByIdAndDelete
      res.json({ message: 'Card deleted successfully' });
    } else {
      res.status(401).json({ message: 'User not authorized' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};


export const getAllCards = async (req: Request, res: Response) => {
  try {
    const cards = await Card.find({});
    res.json(cards);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export const getUserCards = async (req: RequestWithUser, res: Response) => {
  try {
    if (!req.user) throw new Error('user not found');

    // Assuming req.user.id is set by the authentication middleware
    const userCards = await Card.find({ user: req.user.id });
    res.json(userCards);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};


export const getCard = async (req: Request, res: Response) => {
  try {
    const card = await Card.findById(req.params.id);
    if (!card) {
      return res.status(404).json({ message: 'Card not found' });
    }
    res.json(card);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
  return
};

