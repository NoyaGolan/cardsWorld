import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Request, Response } from 'express';
import { IUser }  from '../models/User.js'
export interface RequestWithUser extends Request {
  user?: { id: string; [key: string]: any }; // Adjust this type according to what you actually store in req.user
}

// Utility function to generate JWT
const generateToken = (user: IUser) => {
  const userPayload = {
    id: user._id.toString(), // The user's unique identifier from MongoDB
    isBusiness: user.isBusiness, // Whether the user is a business user
    isAdmin: user.isAdmin // Whether the user is an admin
  };
  return jwt.sign(userPayload, process.env.JWT_SECRET!, {
    expiresIn: '30d', // Token expires in 30 days
  });
};

// Register User
export const registerUser = async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create a new user
    user = new User(req.body);
    await user.save();

    // Generate token
    const token = generateToken(user);

    res.status(201).json({ token });
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
  return
};

// Login User
export const loginUser = async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    // Check for user email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate token
    const token = generateToken(user);

    res.json({ token });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
  return
};

// Get All Users
export const getAllUsers = async (req: Request, res: Response) => {
  try {
    // Assuming you have middleware to check if the user is an admin
    const users = await User.find({});
    res.json(users);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Get User by ID
export const getUser = async (req: Request, res: Response) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
  return
};

// Update User
export const updateUser = async (req: Request, res: Response) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(user);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Delete User
export const deleteUser = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.params.id;
    if (!req.user) throw new Error('user not found');

    // Assuming you're adding the authenticated user to req.user
    if (req.user.id !== userId && !req.user.isAdmin) {
      return res.status(403).json({ message: "Not authorized to delete this user" });
    }

    await User.findByIdAndDelete(userId);
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const changeIsBusinessStatus = async (req: RequestWithUser, res: Response) => {
  const { id } = req.params;
  const { isBusiness } = req.body;
  if (!req.user) throw new Error('user not found');

  // Check if req.user.id is the same as :id or if the user is an admin
  if (req.user.id === id || req.user.isAdmin) {
    try {
      const updatedUser = await User.findByIdAndUpdate(
        id,
        { isBusiness },
        { new: true }
      );
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(updatedUser);
    } catch (error:any) {
      res.status(500).json({ message: 'Error updating user status', error: error.message });
    }
  } else {
    res.status(403).json({ message: "You don't have permission to change this user's status" });
  }
};

