import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import Card from '../models/Card.js';

interface IGetUserAuthInfoRequest extends Request {
  user?: any; // or any other type
}

export const protect = async (req: IGetUserAuthInfoRequest, res: Response, next: NextFunction) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      // Get token from header
      token = req.headers.authorization.split(' ')[1];

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET!);

      // Get user from the token
      req.user = decoded;

      next();
    } catch (error) {
      res.status(401).json({ message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    res.status(401).json({ message: 'Not authorized, no token' });
  }
};

// Middleware to check if the user is the owner of the account or an admin
export const checkAccountOwnerOrAdmin = (req: IGetUserAuthInfoRequest, res: Response, next: NextFunction) => {

  if (req.user.id === req.params.id || req.user.isAdmin) {
    return next();
  } else {
    return res.status(403).json({ message: "Access denied. Not the account owner or an admin." });
  }
};

// Middleware to check if the user is the owner of the account or an admin
export const checkAccountOwner = (req: IGetUserAuthInfoRequest, res: Response, next: NextFunction) => {

  if (req.user.id === req.params.id) {
    return next();
  } else {
    return res.status(403).json({ message: "Access denied. Not the account owner or an admin." });
  }
};

// Middleware to check if the user is the owner of the account or an admin
export const checkAccountOwnerOrAdminCard = async (req: IGetUserAuthInfoRequest, res: Response, next: NextFunction) => {
  try {
    // Await the database operation to complete and get the card
    const card = await Card.findById(req.params.id).exec();

    // If no card is found, return a 404 error
    if (!card) {
      return res.status(404).json({ message: "Card not found." });
    }

    // Check if the user is the card owner or an admin
    if (card.user.toString() === req.user.id || req.user.isAdmin) {
      // If check passes, move to the next middleware
      next();
    } else {
      // If the user is neither the card owner nor an admin, return a 403 error
      return res.status(403).json({ message: "Access denied. Not the account owner or an admin." });
    }
  } catch (error) {
    // Handle any errors that occur during the database operation
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};
