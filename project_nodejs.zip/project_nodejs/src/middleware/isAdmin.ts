import { Request, Response, NextFunction } from 'express';

export interface RequestWithUser extends Request {
    user?: { id: string; [key: string]: any }; // Adjust this type according to what you actually store in req.user
  }
const isAdmin = (req: RequestWithUser, res: Response, next: NextFunction) => {
    if (!req.user) throw new Error('user not found');
    console.log(req.user)
  if (!req.user.isAdmin) {
    return res.status(403).json({ message: "Access denied. Admins only." });
  }
  next();
};
export default isAdmin;