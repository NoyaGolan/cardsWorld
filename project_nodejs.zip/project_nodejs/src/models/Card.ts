import mongoose from 'mongoose';

interface ICard {
  title: string;
  subtitle: string;
  description: string;
  phone: string;
  email: string;
  web: string;
  image: {
    url: string;
    alt: string;
  };
  address: {
    state?: string;
    country: string;
    city: string;
    street: string;
    houseNumber: number;
    zip?: number;
  };
  bizNumber: string;
  likes: mongoose.Types.ObjectId[];
  user: mongoose.Schema.Types.ObjectId;
  createdAt: Date;
}

const cardSchema = new mongoose.Schema<ICard>({
  title: { type: String, required: true },
  subtitle: { type: String, required: true },
  description: { type: String, required: true },
  phone: { type: String, required: true },
  email: { type: String, required: true },
  web: { type: String, required: true },
  image: {
    url: { type: String, required: true },
    alt: { type: String, required: true },
  },
  address: {
    state: { type: String },
    country: { type: String, required: true },
    city: { type: String, required: true },
    street: { type: String, required: true },
    houseNumber: { type: Number, required: true },
    zip: { type: Number },
  },
  bizNumber: { type: String, required: true, unique: true },
  likes:[{ type: mongoose.Types.ObjectId, ref: 'User' }],
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});

const Card = mongoose.model('Card', cardSchema);

export default Card;
