import express from "express";
import { checkAccountOwnerOrAdminCard, protect } from "../middleware/auth.js";
import  isAdmin  from "../middleware/isAdmin.js"; // Import the isAdmin middleware
import {
  getAllCards,
  getUserCards,
  getCard,
  createCard,
  updateCard,
  likeCard,
  deleteCard,
} from "../controllers/cardController.js";
import { validateRequest } from "../middleware/validateRequest.js";
import {
  createCardSchema,
  updateCardSchema,
} from "../validation/cardValidation.js";

const router = express.Router();

router.get("/", getAllCards); // Open to all
router.get("/my-cards", protect, getUserCards); // Protected route
router.get("/:id", getCard); // Open to all
router.post("/", protect, validateRequest(createCardSchema), createCard); // Business user only (check in controller)
router.put("/:id", protect, validateRequest(updateCardSchema), updateCard); // Card owner only (check in controller)
router.patch("/:id/like", protect, likeCard); // Registered user (check in controller)
router.delete("/:id", protect, checkAccountOwnerOrAdminCard, deleteCard); // Admin or card owner (check in controller)

export default router;
