import express from 'express';
import { checkAccountOwner, checkAccountOwnerOrAdmin, protect } from '../middleware/auth.js';
import  isAdmin  from '../middleware/isAdmin.js'; // Import the isAdmin middleware
import { registerUser, loginUser, getAllUsers, getUser, updateUser, deleteUser, changeIsBusinessStatus } from '../controllers/userController.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { registerUserSchema, loginUserSchema, isBusinessUpdateSchema } from '../validation/userValidation.js';

const router = express.Router();

router.post('/register', validateRequest(registerUserSchema), registerUser);
router.post('/login', validateRequest(loginUserSchema), loginUser);
router.get('/', protect, isAdmin, getAllUsers); // Admin only
router.get('/:id', protect, checkAccountOwnerOrAdmin , getUser); // Protected route
router.put('/:id', protect,checkAccountOwner,  updateUser); // Protected route
router.patch('/:id', protect,checkAccountOwner, validateRequest(isBusinessUpdateSchema), changeIsBusinessStatus); // Protected route
router.delete('/:id', protect, checkAccountOwnerOrAdmin, deleteUser); // Admin only

export default router;
