import 'dotenv/config';
import express from 'express';
import userRoutes from './routes/userRoutes.js';
import cardRoutes from './routes/cardRoutes.js';
import connectDB from './config/db.js';
import morgan from 'morgan';
import chalk from 'chalk';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the __dirname equivalent in ES Module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const morganMiddleware = morgan(function (tokens, req, res) {
  return [
    chalk.hex('#ff4757').bold('🌐 ' + tokens.method(req, res)),
    chalk.hex('#34ace0').bold(tokens.url(req, res)),
    chalk.hex('#ffb142').bold(tokens.status(req, res)),
    chalk.hex('#ff5252').bold(tokens['response-time'](req, res) + ' ms'),
  ].join(' ');
});
const corsOptions = {
  origin: process.env.CORS_ORIGIN || 'http://localhost:5000'

};

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors(corsOptions));

app.use(morganMiddleware);

// Connect to database
connectDB();

// Middleware
app.use(express.json());

// Routes
app.use('/api/users', userRoutes);
app.use('/api/cards', cardRoutes);

app.use((req, res, next) => {
  res.status(404).sendFile(path.join(__dirname, 'public', 'notFound.html'));
});
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

app.use((err: any, req: any, res: any, next: any) => {
    console.error(chalk.red('Error:', err.message));
    res.status(err.status || 500).json({
        message: err.message || 'Internal Server Error',
        status: err.status || 500,
    });
});