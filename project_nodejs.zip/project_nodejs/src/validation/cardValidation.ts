// src/validation/cardValidation.ts
import Joi from 'joi';

export const createCardSchema = Joi.object({
  title: Joi.string().required(),
  subtitle: Joi.string().required(),
  description: Joi.string().required(),
  phone: Joi.string().required(),
  email: Joi.string().email().required(),
  web: Joi.string().uri(),
  image: Joi.object({
    url: Joi.string().uri().required(),
    alt: Joi.string().required(),
  }).required(),
  address: Joi.object({
    state: Joi.string(),
    country: Joi.string().required(),
    city: Joi.string().required(),
    street: Joi.string().required(),
    houseNumber: Joi.number().required(),
    zip: Joi.number(),
  }).required(),
  bizNumber: Joi.string().required(),
});

export const updateCardSchema = createCardSchema.min(1); // Allow partial updates
