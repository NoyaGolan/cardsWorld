// src/validation/userValidation.ts
import Joi from 'joi';

export const registerUserSchema = Joi.object({
  name: Joi.object({
    first: Joi.string().required(),
    middle: Joi.string().allow(''),
    last: Joi.string().required(),
  }).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  phone: Joi.string().required(),
  isBusiness: Joi.boolean().required(),
  address: Joi.object({
    state: Joi.string().allow(''),
    country: Joi.string().required(),
    city: Joi.string().required(),
    street: Joi.string().required(),
    houseNumber: Joi.number().required(),
    zip: Joi.number().allow(''),
  }).required(),
  image: Joi.object({
    url: Joi.string().uri().allow(''),
    alt: Joi.string().allow(''),
  }).allow(null),
});

export const loginUserSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});


export const isBusinessUpdateSchema = Joi.object({
  isBusiness: Joi.boolean().required()
});